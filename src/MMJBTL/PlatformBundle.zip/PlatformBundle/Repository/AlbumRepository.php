<?php

namespace MMJBTL\PlatformBundle\Repository;

use Doctrine\ORM\EntityRepository;

class AlbumRepository extends EntityRepository
{


    public function getAlbums() {

        $qb = $this->createQueryBuilder( 'a' );

        $qb->orderby( 'a.titreAlbum' );

        $qb->join( 'a.editeur', 'e' )
        ->addSelect( 'e' );

        $listAlbums = $qb
        ->getQuery()
        ->getResult()
        ;

        return $listAlbums;
    }

    public function photo( $album ) {
        $image = stream_get_contents( $album->getPochette() );
        $image = pack( "H*", $image );
        $response = new \Symfony\Component\HttpFoundation\Response();
        $response->headers->set( 'Content-type', 'image/jpeg' );
        $response->headers->set( 'Content-Transfer-Encoding', 'binary' );
        $response->setContent( $image );
        return $response;
    }
}
