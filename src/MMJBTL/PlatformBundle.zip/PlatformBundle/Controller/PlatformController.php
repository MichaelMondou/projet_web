<?php

namespace MMJBTL\PlatformBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;

class PlatformController extends Controller
{

    public function indexAction()
    {
        return $this->render('PlatformBundle:Platform:index.html.twig');
    }


    public function albumsAction()
    {
        $em = $this
            ->getDoctrine()
            ->getManager();

        $album_repo = $em
            ->getRepository('PlatformBundle:Album');

        $listAlbums = $album_repo
            ->getAlbums();

        return $this->render('PlatformBundle:Platform:albums.html.twig', array(
            'listAlbums'           => $listAlbums,
        ));
    }
}
