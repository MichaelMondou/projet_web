<?php

namespace MMJBTL\PlatformBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class PlatformBundle extends Bundle
{
}
